<?php 
  $mydata = $_REQUEST["mydata"];

  sleep(5);

  print "<p>Hi, $mydata! This is new important data for your web page.</p> ";
?>
