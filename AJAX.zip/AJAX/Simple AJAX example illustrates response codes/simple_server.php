<?php 
  $mydata = $_REQUEST["mydata"];
  print "<p>Hi, $mydata! This is new important data for your web page.</p> ";
?>
